Please execute the following command to check whether your circuit is correct:
./01_sim +test_zero_len
./01_sim +test_single_rw
./01_sim +test_burst_rw
./01_sim +test_wait_vld

Each pattern will have some pairs of test items

test_zero_len
The message length is zero

test_single_rw:
Each msg_vld only maintains 1 cycle
Each word_rdy only maintains 1 cycle

test_burst_rw:
Each msg_vld maintains 5~8 cycles
Each word_rdy only maintains 5~8 cycles

test_single_rw:
Check whether your msg_rdy is waiting for msg_vld to rise before pulling up

