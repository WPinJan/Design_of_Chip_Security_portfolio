[example of all test cases]
./01_sim +test_case_1 +define+TV1
./01_sim +test_case_1 +define+TV2
./01_sim +test_case_1 +define+USE_DPI
./01_sim +test_case_2 +define+TV1
./01_sim +test_case_2 +define+TV2
./01_sim +test_case_2 +define+USE_DPI
./01_sim +test_case_3 +define+TV1
./01_sim +test_case_3 +define+TV2
./01_sim +test_case_3 +define+USE_DPI
./01_sim +test_case_4 +define+TV1
./01_sim +test_case_4 +define+TV2
./01_sim +test_case_4 +define+USE_DPI

[example of debug]
./01_sim ... +define+SHW_PSMSG=1 +define+FL_STPSIM=1 +define+USE_FSDB +FSDB

[open verdi and waveform gui]
./02_wave

[run regression and coverage]
./03_regrun

[report regression result]
./04_regrpt

[open coverage report gui]
./05_covgui

[cleanup sim folder]
./09_clean
