the file is used for 01_make

test_case || length
=======================
 1        || 1000
 2        || 200 
