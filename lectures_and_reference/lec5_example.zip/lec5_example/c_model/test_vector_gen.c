#include<string.h>
#include"./lib/gen_pat.c"

int main()
{
   unsigned int i,status;
            int tc;
   unsigned int test_len;
   unsigned int gold_len;
   unsigned int  *rn_32b;
   unsigned char *rn_8b;

   FILE *fPtr_out1 = fopen("test_vec.dat","w");//for TX (32-bit)
   FILE *fPtr_out2 = fopen("gold_vec.dat","w");//for RX golden (8-bit)

   // test file not existing
   if (fPtr_out1 == NULL || fPtr_out2 == NULL){
      printf("Error! Could not open file\n");
      exit(-1);
   }

   printf("//---------------------------//\n");
   printf("//-- Test Vector Generator --//\n");
   printf("//---------------------------//\n");

   printf("Choose Test Case(Type in 1 or 2):\n");
   scanf("%d", &tc);

   if(tc==1) test_len=1000;
   else      test_len=200;//test case = 2
   printf("test length = %d\n",test_len);

 //printf("Enter the 32-bit test length:\n");
 //scanf("%d", &test_len);
   
   if(test_len <=0){
      printf("The value (%d) must be positive (>0)!\n", test_len);
      fclose(fPtr_out1);
      fclose(fPtr_out2);
      return 1;
   }
   else{
      rn_32b = (unsigned int*)malloc(test_len * sizeof(unsigned int));

      c_gen_test_vec(rn_32b, test_len);
      for(i=0; i<test_len; i=i+1){//test vector length
         fprintf(fPtr_out1,"@%08x ",i);

         fprintf(fPtr_out1,"%08x",rn_32b[i]);
         fprintf(fPtr_out1,"\n");
      }

      gold_len = 4*test_len;
      rn_8b = (unsigned char*)malloc(gold_len * sizeof(unsigned int));

      status = c_get_gold_vec(rn_8b, rn_32b, test_len);
      if(status == 0){//unpacked array for RX
         for(i=0; i<gold_len; i=i+1){//golden vector length
            fprintf(fPtr_out2,"@%08x %02x\n",i,rn_8b[i]);
         }
      }
      else{
         printf("Get golden vector fail!:\n");
      }

      free(rn_32b);
      free(rn_8b);

      fclose(fPtr_out1);
      fclose(fPtr_out2);
      return (0);
   }
}
