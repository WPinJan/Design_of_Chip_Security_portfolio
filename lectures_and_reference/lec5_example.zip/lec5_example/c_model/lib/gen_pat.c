#include"gen_pat.h"
int c_gen_test_vec(unsigned int *test_vec_int, unsigned int test_len)
{
    unsigned int i;

    srand((unsigned)time(NULL));//set random seed = time
    for(i=0; i<test_len; i=i+1){
      *(test_vec_int+i) = random();
    }

    return 0;
}

int c_get_gold_vec(unsigned char *gold_vec_byte, unsigned int *test_vec_int, unsigned int test_len)
{
    unsigned int i,j;
    unsigned int tmp;

    if(test_vec_int==NULL){
       printf("test_vec_int is not allocated.\n");
       return 1;
    }
    else{
      for(i=0; i<test_len; i=i+1){
         tmp = test_vec_int[i];
       //printf("tmp[%08x] = %08x\n",i,tmp);
         for(j=0; j<4; j=j+1){
            *(gold_vec_byte+i*4+j) = tmp & 0xff;
          //printf("gold_vec_byte[%08x] = %02x\n",i*4+j,gold_vec_byte[i*4+j]);
            tmp = tmp>>8;
         }   
      }

      return 0;
    }  
}
