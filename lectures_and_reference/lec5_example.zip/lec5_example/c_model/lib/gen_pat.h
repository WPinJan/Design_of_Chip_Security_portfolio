#ifndef GEN_PAT_H
#define GEN_PAT_H

#include<stdio.h>
#include<stdlib.h>
#include<time.h>

int c_gen_test_vec(unsigned int*, unsigned int);
int c_get_gold_vec(unsigned char*, unsigned int*, unsigned int);

#endif //GEN_PAT_H HEADER
