TEST CASE      || Delay(Cycle) || DATA RATE(TX)  || DATA RATE(RX)  
===================================================================
test_case_1    || TX) 100      || valid = 1      || valid = 1 or 0 
test_case_2    || TX) 100      || valid = 1 or 0 || valid = 1      
test_case_3    || no           || valid = 1 or 0 || valid = 1 or 0 
test_case_4    || RX) 100      || valid = 1      || valid = 1      
